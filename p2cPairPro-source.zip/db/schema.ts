import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

// The authoritative classroom state is stored as one JSON document.
export const appState = sqliteTable("app_state", {
  id: text("id").primaryKey(),
  valueJson: text("value_json").notNull(),
  revision: integer("revision").notNull().default(0),
  updatedAt: text("updated_at").notNull(),
});
