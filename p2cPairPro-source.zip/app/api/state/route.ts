import { eq } from "drizzle-orm";
import { getDb } from "../../../db";
import { appState } from "../../../db/schema";

const initial = { absent: [], selections: {}, progress: {}, maxCount: 3 };
const now = () => new Date().toISOString();

export async function GET() {
  try {
    const db = getDb();
    let row = await db.query.appState.findFirst({ where: eq(appState.id, "classroom") });
    if (!row) {
      await db.insert(appState).values({ id: "classroom", valueJson: JSON.stringify(initial), revision: 0, updatedAt: now() });
      row = { id: "classroom", valueJson: JSON.stringify(initial), revision: 0, updatedAt: now() };
    }
    return Response.json({ state: { ...JSON.parse(row.valueJson), revision: row.revision } });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "データを読み込めませんでした" }, { status: 500 }); }
}

export async function PUT(request: Request) {
  try {
    const payload = await request.json() as { state?: unknown; revision?: number };
    if (!payload.state || typeof payload.revision !== "number") return Response.json({ error: "不正なデータです" }, { status: 400 });
    const db = getDb();
    const current = await db.query.appState.findFirst({ where: eq(appState.id, "classroom") });
    if (!current || current.revision !== payload.revision) return Response.json({ state: current ? { ...JSON.parse(current.valueJson), revision: current.revision } : null, error: "競合" }, { status: 409 });
    const revision = current.revision + 1;
    await db.update(appState).set({ valueJson: JSON.stringify(payload.state), revision, updatedAt: now() }).where(eq(appState.id, "classroom"));
    return Response.json({ state: { ...(payload.state as object), revision } });
  } catch (error) { return Response.json({ error: error instanceof Error ? error.message : "保存できませんでした" }, { status: 500 }); }
}
