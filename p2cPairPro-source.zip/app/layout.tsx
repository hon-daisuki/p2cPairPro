import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "P2C 座席ペア・環境チェック",
  description: "P2Cの座席ペアと環境チェック進捗管理",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="ja">
      <body className="antialiased">{children}</body>
    </html>
  );
}
