CREATE TABLE `app_state` (
  `id` text PRIMARY KEY NOT NULL,
  `value_json` text NOT NULL,
  `revision` integer DEFAULT 0 NOT NULL,
  `updated_at` text NOT NULL
);
